import { Link, useNavigate } from "react-router-dom";

function BeritaFooter() {
  const navigate = useNavigate();

  return (
    <footer
      style={{
        background: "#064d00",
        color: "#ffffff",
        padding: "35px 25px 20px",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "1200px",
          margin: "0 auto",
          display: "grid",
          gridTemplateColumns:
            "1.2fr 1fr 1fr 1.2fr",
          gap: "40px",
        }}
      >
        {/* SEKOLAH */}
        <div>
          <h3 style={footerTitle}>
            SMA Harapan Jaya
          </h3>

          <p style={footerText}>
            Membentuk generasi pembelajar berkarakter
            Pancasila, unggul dalam sains dan teknologi,
            berwawasan global, dan berbudaya lingkungan
            hidup lestari.
          </p>

          <span
            style={{
              display: "inline-block",
              marginTop: "8px",
              padding: "6px 9px",
              borderRadius: "5px",
              background: "#0c5e0a",
              color: "#e4ee00",
              fontSize: "8px",
              fontWeight: "bold",
            }}
          >
            TERAKREDITASI A (UNGGUL) BAN-S/M
          </span>
        </div>

        {/* NAVIGASI */}
        <div>
          <h3 style={footerTitle}>
            Navigasi Utama
          </h3>

          <FooterLink to="/profil" text="Profil Sekolah" />
          <FooterLink to="/visi-misi" text="Visi & Misi" />
          <FooterLink
            to="/kurikulum"
            text="Kurikulum Merdeka"
          />
          <FooterLink
            to="/agenda"
            text="Kalender Akademik"
          />
          <FooterLink
            to="/ppdb"
            text="PPDB 2026/2027"
          />
          <FooterLink
            to="/portal-sis"
            text="Portal E-Learning SIS"
          />
        </div>

        {/* ALAMAT */}
        <div>
          <h3 style={footerTitle}>
            Alamat Kampus
          </h3>

          <p style={footerText}>
            Jl. Harapan Bangsa No. 88,
            Jagakarsa, Jakarta Selatan,
            DKI Jakarta 12620
          </p>

          <p style={footerText}>
            ☎ Telp: (021) 781-9920 / 781-9921
          </p>

          <button
            onClick={() =>
              window.open(
                "https://maps.google.com/?q=Jl.+Harapan+Bangsa+No.+88+Jakarta",
                "_blank"
              )
            }
            style={{
              marginTop: "8px",
              padding: 0,
              border: "none",
              background: "transparent",
              color: "#dce900",
              cursor: "pointer",
              fontSize: "10px",
            }}
          >
            ⌖ Buka di Google Maps
          </button>
        </div>

        {/* SOSIAL MEDIA */}
        <div>
          <h3 style={footerTitle}>
            Terhubung Bersama Kami
          </h3>

          <p style={footerText}>
            Ikuti media sosial resmi SMA Harapan Jaya
            untuk galeri dokumentasi kegiatan
            ekstrakurikuler dan info prestasi harian.
          </p>

          <div
            style={{
              display: "flex",
              gap: "8px",
              marginTop: "15px",
            }}
          >
            {["▶", "◎", "♣", "◉"].map(
              (icon, index) => (
                <button
                  key={index}
                  onClick={() =>
                    navigate("/media-sosial")
                  }
                  style={{
                    width: "30px",
                    height: "30px",
                    border: "none",
                    borderRadius: "50%",
                    background: "#31732d",
                    color: "#ffffff",
                    cursor: "pointer",
                  }}
                >
                  {icon}
                </button>
              )
            )}
          </div>

          <button
            onClick={() => navigate("/aspirasi")}
            style={{
              marginTop: "15px",
              padding: "9px 13px",
              border: "none",
              borderRadius: "6px",
              background: "#ffffff",
              color: "#164616",
              cursor: "pointer",
              fontSize: "9px",
            }}
          >
            ⓘ Saluran Aspirasi & WBS
          </button>
        </div>
      </div>

      {/* COPYRIGHT */}
      <div
        style={{
          width: "100%",
          maxWidth: "1200px",
          margin: "30px auto 0",
          paddingTop: "18px",
          borderTop:
            "1px solid rgba(255,255,255,.15)",
          display: "flex",
          justifyContent: "space-between",
          gap: "20px",
          color: "#bdd0ba",
          fontSize: "9px",
        }}
      >
        <span>
          © 2026 SMA Harapan Jaya. Hak Cipta Dilindungi
          Undang-Undang. Terakreditasi Unggul (A) BAN-S/M.
        </span>

        <div
          style={{
            display: "flex",
            gap: "20px",
          }}
        >
          <button
            onClick={() =>
              navigate("/kebijakan-privasi")
            }
            style={bottomButton}
          >
            Kebijakan Privasi
          </button>

          <button
            onClick={() =>
              navigate("/syarat-ketentuan")
            }
            style={bottomButton}
          >
            Syarat & Ketentuan
          </button>

          <button
            onClick={() => navigate("/kontak")}
            style={bottomButton}
          >
            Kontak & Pengaduan
          </button>
        </div>
      </div>
    </footer>
  );
}

function FooterLink({ to, text }) {
  return (
    <Link
      to={to}
      style={{
        display: "block",
        marginBottom: "10px",
        color: "#cbd9c8",
        textDecoration: "none",
        fontSize: "10px",
      }}
    >
      {text}
    </Link>
  );
}

const footerTitle = {
  margin: "0 0 15px",
  color: "#e6ed00",
  fontSize: "14px",
};

const footerText = {
  margin: 0,
  color: "#c2d2be",
  fontSize: "10px",
  lineHeight: "1.7",
};

const bottomButton = {
  border: "none",
  background: "transparent",
  color: "#bdd0ba",
  cursor: "pointer",
  fontSize: "9px",
};

export default BeritaFooter;