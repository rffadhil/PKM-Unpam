import BeritaCard from "./BeritaCard";

function KumpulanBerita({
  berita,
  halaman,
  setHalaman,
}) {
  return (
    <section>
      {/* JUDUL */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "17px",
        }}
      >
        <h2
          style={{
            margin: 0,
            paddingLeft: "12px",
            borderLeft: "5px solid #438e43",
            color: "#29442d",
            fontSize: "17px",
          }}
        >
          Kumpulan Warta Terkini
        </h2>

        <span
          style={{
            color: "#98a39d",
            fontSize: "10px",
          }}
        >
          Menampilkan 1–6 dari 48 artikel
        </span>
      </div>

      {/* CARD */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "16px",
        }}
      >
        {berita.map((item) => (
          <BeritaCard
            key={item.id}
            berita={item}
          />
        ))}
      </div>

      {/* PAGINATION */}
      <div
        style={{
          marginTop: "25px",
          padding: "12px",
          background: "#ffffff",
          border: "1px solid #e0e8e1",
          borderRadius: "8px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <span
          style={{
            color: "#8b968f",
            fontSize: "9px",
          }}
        >
          Menampilkan halaman {halaman} dari 5
          (Total 48 Berita)
        </span>

        <div
          style={{
            display: "flex",
            gap: "4px",
          }}
        >
          <button
            disabled={halaman === 1}
            onClick={() =>
              setHalaman(Math.max(1, halaman - 1))
            }
            style={paginationButton(halaman === 1)}
          >
            ‹ Sebelumnya
          </button>

          {[1, 2, 3, 4, 5].map((nomor) => (
            <button
              key={nomor}
              onClick={() => setHalaman(nomor)}
              style={paginationButton(
                false,
                halaman === nomor
              )}
            >
              {nomor}
            </button>
          ))}

          <button
            disabled={halaman === 5}
            onClick={() =>
              setHalaman(Math.min(5, halaman + 1))
            }
            style={paginationButton(halaman === 5)}
          >
            Selanjutnya ›
          </button>
        </div>
      </div>
    </section>
  );
}

function paginationButton(disabled, active = false) {
  return {
    minWidth: "29px",
    height: "29px",
    padding: "0 8px",
    border: active
      ? "1px solid #063e0a"
      : "1px solid #dfe6e0",
    borderRadius: "5px",
    background: active ? "#063e0a" : "#ffffff",
    color: active ? "#ffffff" : "#66736b",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.45 : 1,
    fontSize: "9px",
  };
}

export default KumpulanBerita;