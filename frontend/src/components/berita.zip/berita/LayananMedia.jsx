function LayananMedia() {
  return (
    <div
      style={{
        marginTop: "18px",
        padding: "18px",
        background: "#f0f4ff",
        border: "1px solid #dbe4f1",
        borderRadius: "9px",
      }}
    >
      <h3
        style={{
          margin: "0 0 9px",
          color: "#46704c",
          fontSize: "12px",
        }}
      >
        ◉ Layanan Pers & Liputan Media
      </h3>

      <p
        style={{
          margin: "0 0 10px",
          color: "#7d8c82",
          fontSize: "9px",
          lineHeight: "1.5",
        }}
      >
        Untuk kebutuhan verifikasi berita sekolah,
        izin peliputan, atau konfirmasi humas:
      </p>

      <button
        onClick={() =>
          (window.location.href =
            "mailto:redaksi.warta@smaharapanjaya.sch.id")
        }
        style={contactButton}
      >
        Email: redaksi.warta@smaharapanjaya.sch.id
      </button>

      <button
        onClick={() =>
          (window.location.href =
            "tel:+6281288997766")
        }
        style={contactButton}
      >
        Hotline: +62 812-8899-7766 (Bu Ratna - Humas)
      </button>
    </div>
  );
}

const contactButton = {
  display: "block",
  padding: "4px 0",
  border: "none",
  background: "transparent",
  color: "#52645a",
  cursor: "pointer",
  textAlign: "left",
  fontSize: "9px",
};

export default LayananMedia;