import { Link, useNavigate } from "react-router-dom";

function BeritaHeader() {
  const navigate = useNavigate();

  return (
    <>
      {/* TOP BAR */}
      <div
        style={{
          background: "#064d00",
          color: "#ffffff",
          minHeight: "32px",
          display: "flex",
          alignItems: "center",
          fontSize: "11px",
        }}
      >
        <div
          style={{
            width: "100%",
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "0 25px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div
            style={{
              display: "flex",
              gap: "20px",
              alignItems: "center",
            }}
          >
            <span>🟢 NPSN Resmi: 20103290</span>
            <span>☎ (021) 781-9920 / humas@smaharapanjaya.sch.id</span>
            <span>◷ Senin - Jumat: 06.45 - 15.30 WIB</span>
          </div>

          <div
            style={{
              display: "flex",
              gap: "9px",
              alignItems: "center",
            }}
          >
            <button
              onClick={() => navigate("/adiwiyata")}
              style={{
                border: "none",
                borderRadius: "4px",
                background: "#3d710f",
                color: "#ffffff",
                padding: "5px 9px",
                fontSize: "8px",
                cursor: "pointer",
              }}
            >
              SEKOLAH ADIWIYATA MANDIRI
            </button>

            <button
              onClick={() => navigate("/portal-sis")}
              style={{
                border: "none",
                background: "transparent",
                color: "#e6ee00",
                fontSize: "9px",
                cursor: "pointer",
              }}
            >
              ◉ Portal SIS
            </button>
          </div>
        </div>
      </div>

      {/* NAVBAR */}
      <header
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #e5ebe6",
        }}
      >
        <div
          style={{
            width: "100%",
            maxWidth: "1200px",
            minHeight: "86px",
            margin: "0 auto",
            padding: "0 25px",
            display: "flex",
            alignItems: "center",
            gap: "28px",
          }}
        >
          {/* LOGO / NAMA SEKOLAH */}
          <Link
            to="/"
            style={{
              textDecoration: "none",
              minWidth: "165px",
            }}
          >
            <div
              style={{
                fontFamily: "Georgia, serif",
                color: "#173d19",
                fontSize: "20px",
                fontWeight: "bold",
              }}
            >
              SMA Harapan Jaya
            </div>

            <div
              style={{
                marginTop: "4px",
                color: "#8b968f",
                fontSize: "10px",
              }}
            >
              Terakreditasi Unggul (A) BAN-S/M
            </div>
          </Link>

          {/* NAVIGASI */}
          <nav
            style={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              gap: "25px",
            }}
          >
            <NavItem to="/" text="Beranda" />
            <NavItem to="/profil" text="Profil" />
            <NavItem
              to="/berita"
              text="Berita"
              active
            />
            <NavItem to="/agenda" text="Agenda" />
            <NavItem to="/galeri" text="Galeri" />
            <NavItem to="/kontak" text="Kontak" />
          </nav>

          {/* BUTTON KANAN */}
          <div
            style={{
              display: "flex",
              gap: "9px",
            }}
          >
            <button
              onClick={() => navigate("/dokumen")}
              style={{
                border: "1px solid #5b8e55",
                background: "#ffffff",
                color: "#3e763c",
                borderRadius: "6px",
                padding: "9px 16px",
                cursor: "pointer",
                fontSize: "11px",
              }}
            >
              Dokumen
            </button>

            <button
              onClick={() => navigate("/ppdb")}
              style={{
                border: "none",
                background: "#e4e900",
                color: "#254600",
                borderRadius: "18px",
                padding: "9px 18px",
                cursor: "pointer",
                fontSize: "11px",
                fontWeight: "bold",
              }}
            >
              Daftar PPDB
            </button>
          </div>
        </div>
      </header>
    </>
  );
}

function NavItem({ to, text, active }) {
  return (
    <Link
      to={to}
      style={{
        textDecoration: "none",
        color: active ? "#438443" : "#344039",
        fontSize: "12px",
        fontWeight: active ? "600" : "400",
        padding: "32px 0 28px",
        borderBottom: active
          ? "2px solid #438443"
          : "2px solid transparent",
      }}
    >
      {text}
    </Link>
  );
}

export default BeritaHeader;