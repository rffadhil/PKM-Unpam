import { useNavigate } from "react-router-dom";

function BeritaUtama() {
  const navigate = useNavigate();

  return (
    <article
      style={{
        display: "grid",
        gridTemplateColumns: "56% 44%",
        overflow: "hidden",
        background: "#ffffff",
        border: "1px solid #dce5de",
        borderRadius: "9px",
      }}
    >
      {/* GAMBAR */}
      <div
        style={{
          position: "relative",
          minHeight: "350px",
        }}
      >
        <img
          src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=1200&q=80"
          alt="Tim Robotik SMA Harapan Jaya"
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: "block",
          }}
        />

        <div
          style={{
            position: "absolute",
            top: "14px",
            left: "14px",
            display: "flex",
            gap: "7px",
          }}
        >
          <span
            style={{
              background: "#dce800",
              color: "#234900",
              padding: "6px 9px",
              borderRadius: "14px",
              fontSize: "9px",
              fontWeight: "bold",
            }}
          >
            🏆 Prestasi Internasional
          </span>

          <span
            style={{
              background: "#075000",
              color: "#ffffff",
              padding: "6px 9px",
              borderRadius: "14px",
              fontSize: "9px",
            }}
          >
            Headline Utama
          </span>
        </div>
      </div>

      {/* INFORMASI */}
      <div
        style={{
          padding: "30px",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            display: "flex",
            gap: "15px",
            color: "#859189",
            fontSize: "10px",
          }}
        >
          <span>▣ 24 Februari 2026</span>
          <span>◷ 4 menit baca</span>
        </div>

        <h2
          style={{
            margin: "14px 0",
            color: "#143d17",
            fontFamily: "Georgia, serif",
            fontSize: "24px",
            lineHeight: "1.3",
          }}
        >
          Tim Robotik SMA Harapan Jaya Sabet
          Medali Emas WRO 2026 di Tokyo
        </h2>

        <p
          style={{
            margin: 0,
            color: "#7d8981",
            fontSize: "12px",
            lineHeight: "1.7",
          }}
        >
          Karya inovasi robot pemilah sampah otomatis
          berbasis sensor kecerdasan buatan (AI) yang
          dirancang siswa kelas XI IPA 1 berhasil
          menyingkirkan 45 tim mancanegara pada putaran
          final World Robot Olympiad 2026 di Odaiba,
          Tokyo.
        </p>

        <div
          style={{
            marginTop: "auto",
            paddingTop: "20px",
            borderTop: "1px solid #edf0ed",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div
            style={{
              display: "flex",
              gap: "9px",
              alignItems: "center",
            }}
          >
            <div
              style={{
                width: "31px",
                height: "31px",
                borderRadius: "50%",
                background: "#eef5eb",
                color: "#428045",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "10px",
                fontWeight: "bold",
              }}
            >
              HK
            </div>

            <div>
              <strong
                style={{
                  display: "block",
                  fontSize: "11px",
                }}
              >
                Humas & Kesiswaan
              </strong>

              <small
                style={{
                  color: "#9ca69f",
                  fontSize: "9px",
                }}
              >
                Editor Resmi
              </small>
            </div>
          </div>

          <button
            onClick={() =>
              navigate("/berita/headline-wro-2026")
            }
            style={{
              border: "none",
              background: "#063e0a",
              color: "#ffffff",
              borderRadius: "6px",
              padding: "10px 13px",
              cursor: "pointer",
              fontSize: "10px",
            }}
          >
            Baca Selengkapnya →
          </button>
        </div>
      </div>
    </article>
  );
}

export default BeritaUtama;