import { useNavigate } from "react-router-dom";

const pengumumanData = [
  {
    nomor: "421.3/089/SMA-HJ/2026",
    tanggal: "25 Feb 2026",
    judul:
      "Verifikasi Berkas Calon Peserta Didik Baru (PPDB) Jalur Prestasi 2026/2027",
    isi:
      "Batas akhir unggah portofolio sertifikat kejuaraan tingkat kota & provinsi diperpanjang hingga 2 Maret 2026 pukul 15.00 WIB.",
    aksi: "Unduh Petunjuk Teknis (PDF)",
  },
  {
    nomor: "421.3/082/SMA-HJ/2026",
    tanggal: "21 Feb 2026",
    judul:
      "Jadwal Gladi Bersih Asesmen Nasional Berbasis Komputer (ANBK) 2026",
    isi:
      "Wajib diikuti oleh seluruh siswa kelas XI. Pembagian sesi dan ruang server telah dirilis melalui portal SIS.",
    aksi: "Lihat Pembagian Sesi",
  },
  {
    nomor: "421.3/077/SMA-HJ/2026",
    tanggal: "14 Feb 2026",
    judul:
      "Surat Edaran Libur Awal Ramadhan 1447 H & Penyesuaian Jam Belajar",
    isi:
      "Informasi penyesuaian jam kepulangan siswa selama bulan puasa dan jadwal pengantaran selama ramadhan.",
    aksi: "Unduh Surat Edaran (PDF)",
  },
];

function PengumumanResmi() {
  const navigate = useNavigate();

  return (
    <div
      style={{
        background: "#075000",
        border: "2px solid #91a800",
        borderRadius: "9px",
        padding: "18px",
        color: "#ffffff",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "15px",
        }}
      >
        <h2
          style={{
            margin: 0,
            fontSize: "14px",
          }}
        >
          📢 Pengumuman Resmi
        </h2>

        <span
          style={{
            padding: "5px 7px",
            background: "#dce800",
            color: "#284b00",
            fontSize: "8px",
            fontWeight: "bold",
          }}
        >
          PENTING
        </span>
      </div>

      {pengumumanData.map((item) => (
        <div
          key={item.nomor}
          style={{
            padding: "12px",
            marginBottom: "10px",
            border:
              "1px solid rgba(160,210,40,.35)",
            borderRadius: "7px",
            background: "rgba(0,60,0,.5)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              color: "#b6cc5d",
              fontSize: "8px",
            }}
          >
            <span>No: {item.nomor}</span>
            <span>{item.tanggal}</span>
          </div>

          <h3
            style={{
              margin: "7px 0",
              color: "#ffffff",
              fontSize: "11px",
              lineHeight: "1.4",
            }}
          >
            {item.judul}
          </h3>

          <p
            style={{
              color: "#c3d0bd",
              fontSize: "8px",
              lineHeight: "1.5",
            }}
          >
            {item.isi}
          </p>

          <button
            onClick={() => navigate("/pengumuman")}
            style={{
              padding: 0,
              border: "none",
              background: "transparent",
              color: "#dce900",
              cursor: "pointer",
              fontSize: "8px",
            }}
          >
            ↓ {item.aksi}
          </button>
        </div>
      ))}

      <button
        onClick={() => navigate("/pengumuman")}
        style={{
          width: "100%",
          padding: "5px 0 0",
          border: "none",
          background: "transparent",
          color: "#e0ed00",
          cursor: "pointer",
          fontSize: "10px",
        }}
      >
        Lihat Seluruh Pengumuman (34) →
      </button>
    </div>
  );
}

export default PengumumanResmi;