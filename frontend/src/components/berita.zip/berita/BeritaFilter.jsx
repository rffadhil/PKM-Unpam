const kategoriData = [
  ["Semua Berita", 48],
  ["Prestasi Siswa", 18],
  ["Kegiatan Akademik", 14],
  ["Adiwiyata & Lingkungan", 9],
  ["Pengumuman Resmi", 7],
];

function BeritaFilter({
  search,
  setSearch,
  kategoriAktif,
  setKategoriAktif,
  sort,
  setSort,
}) {
  return (
    <section
      style={{
        background: "#ffffff",
        padding: "18px 25px 32px",
        borderBottom: "1px solid #e5ebe6",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "1200px",
          margin: "0 auto",
        }}
      >
        {/* SEARCH + SORT */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "20px",
          }}
        >
          <div
            style={{
              flex: 1,
              height: "44px",
              display: "flex",
              alignItems: "center",
              padding: "0 14px",
              border: "1px solid #dce5de",
              borderRadius: "7px",
            }}
          >
            <span
              style={{
                marginRight: "10px",
                color: "#829188",
                fontSize: "20px",
              }}
            >
              ⌕
            </span>

            <input
              type="text"
              value={search}
              onChange={(event) =>
                setSearch(event.target.value)
              }
              placeholder="Cari judul berita, prestasi siswa, atau nomor pengumuman..."
              style={{
                width: "100%",
                border: "none",
                outline: "none",
                fontSize: "12px",
                color: "#344039",
              }}
            />
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "8px",
              color: "#87938b",
              fontSize: "11px",
            }}
          >
            <span>☷</span>
            <span>Urutkan:</span>

            <select
              value={sort}
              onChange={(event) =>
                setSort(event.target.value)
              }
              style={{
                height: "42px",
                padding: "0 12px",
                border: "1px solid #dce5de",
                borderRadius: "7px",
                background: "#ffffff",
                cursor: "pointer",
                fontSize: "11px",
              }}
            >
              <option value="terbaru">
                Paling Baru (Terbaru)
              </option>

              <option value="terlama">
                Paling Lama
              </option>
            </select>
          </div>
        </div>

        {/* KATEGORI */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "8px",
            marginTop: "17px",
          }}
        >
          {kategoriData.map(([nama, jumlah]) => {
            const aktif = kategoriAktif === nama;

            return (
              <button
                key={nama}
                onClick={() => setKategoriAktif(nama)}
                style={{
                  padding: "9px 15px",
                  borderRadius: "20px",
                  border: aktif
                    ? "1px solid #063e0a"
                    : "1px solid #dfe7e0",
                  background: aktif
                    ? "#063e0a"
                    : "#f9fbf9",
                  color: aktif
                    ? "#ffffff"
                    : "#354139",
                  cursor: "pointer",
                  fontSize: "11px",
                }}
              >
                {nama} ({jumlah})
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export default BeritaFilter;