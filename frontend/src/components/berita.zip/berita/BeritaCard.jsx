import { useNavigate } from "react-router-dom";

function BeritaCard({ berita }) {
  const navigate = useNavigate();

  return (
    <article
      style={{
        background: "#ffffff",
        border: "1px solid #dfe7e1",
        borderRadius: "7px",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          height: "145px",
          position: "relative",
        }}
      >
        <img
          src={berita.gambar}
          alt={berita.judul}
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: "block",
          }}
        />

        <span
          style={{
            position: "absolute",
            top: "9px",
            left: "9px",
            padding: "5px 8px",
            borderRadius: "12px",
            background: "#165d19",
            color: "#ffffff",
            fontSize: "8px",
          }}
        >
          {berita.kategori}
        </span>
      </div>

      <div style={{ padding: "12px" }}>
        <div
          style={{
            color: "#8c9890",
            fontSize: "9px",
          }}
        >
          ▣ {berita.tanggal}
        </div>

        <h3
          style={{
            margin: "8px 0",
            color: "#304037",
            fontFamily: "Georgia, serif",
            fontSize: "13px",
            lineHeight: "1.4",
          }}
        >
          {berita.judul}
        </h3>

        <p
          style={{
            minHeight: "28px",
            margin: 0,
            color: "#8a958e",
            fontSize: "9px",
            lineHeight: "1.5",
          }}
        >
          {berita.deskripsi}
        </p>

        <div
          style={{
            marginTop: "12px",
            paddingTop: "9px",
            borderTop: "1px solid #edf1ed",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span
            style={{
              color: "#8c9890",
              fontSize: "8px",
            }}
          >
            {berita.baca}
          </span>

          <button
            onClick={() =>
              navigate(`/berita/${berita.id}`)
            }
            style={{
              border: "none",
              background: "transparent",
              color: "#438643",
              cursor: "pointer",
              fontSize: "9px",
              fontWeight: "600",
            }}
          >
            Baca Selengkapnya →
          </button>
        </div>
      </div>
    </article>
  );
}

export default BeritaCard;